(function(){var e=new Date().getFullYear();document.querySelector("#currentYear").innerHTML=e})();
